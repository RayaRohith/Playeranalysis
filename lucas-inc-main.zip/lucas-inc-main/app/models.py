from mongoengine import Document, StringField, IntField, FloatField, ListField

class PlayerPerformance(Document):
    player_name = StringField(required=True, max_length=200)
    age = IntField(required=True)
    position = StringField(required=True)
    games_played = IntField(required=True)
    average_score = FloatField(required=True)
    strengths = ListField(StringField(max_length=50))
    weaknesses = ListField(StringField(max_length=50))
