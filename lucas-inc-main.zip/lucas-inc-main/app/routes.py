from app import app, mongo
from flask import Flask, render_template, request, redirect, url_for
from flask_pymongo import PyMongo

@app.route('/')
def index():
    return "S1961348"

@app.route('/submit_data', methods=['GET', 'POST'])
def submit_data():
    if request.method == 'POST':
        # Collect data from the form
        player_data = {
            'player_name': request.form.get('player_name'),
            'age': int(request.form.get('age')),
            'position': request.form.get('position'),
            'games_played': int(request.form.get('games_played')),
            'average_score': float(request.form.get('average_score')),
            # Add additional fields as necessary
        }

        # Insert the data into MongoDB
        mongo.db.players.insert_one(player_data)
        return redirect(url_for('submission_success'))
    else:
        return '2'
    return render_template('submit_player.html')
    # Process form data and insert it into MongoDB
    # Redirect to another view that displays the analysis results

@app.route('/submission_success')
def submission_success():
    return 'Player data submitted successfully!'


app = Flask(__name__)
app.config["MONGO_URI"] = "mongodb://localhost:27017/yourDatabaseName"
mongo = PyMongo(app)

