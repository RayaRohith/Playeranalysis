from flask import Flask
from flask_pymongo import PyMongo
from mongoengine import connect

mongo=PyMongo
app = Flask(__name__)
app.config["MONGO_URI"] = "mongodb://localhost:27017/players"
mongo.init_app(app)

connect('your_db_name', host='localhost', port=27017)

